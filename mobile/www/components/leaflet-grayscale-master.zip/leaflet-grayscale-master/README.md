# Leaflet.TileLayer.Grayscale

A regular TileLayer with grayscale makeover.

## Usage

Just use `L.tileLayer.grayscale(url, options)` instead of `L.tileLayer(url, options)`.

## Example

http://zverik.github.com/leaflet-grayscale/

## License

This plugin was written by Ilya Zverev and published under WTFPL license.
